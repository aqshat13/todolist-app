# TODO LIST APP - MERN STACK BY Akshat dubey

## Run `npm install` to install all the required packages in listed in package.json. 


### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.

### `npm run build`


This will create a minified build.

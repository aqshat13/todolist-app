

### Please change (dot)env file to .env after downloading.

## To run:

### 1. npm install 
### 2. npm start
### or
### 3. nodemon app.js 

